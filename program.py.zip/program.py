def feet_to_cm(feet):
    return feet * 30.48

def inches_to_cm(inches):
    return inches * 2.54

def yards_to_cm(yards):
    return yards * 91.44

option = int(input())
    
if option != 1 and option != 2 and option != 3:
    print ("Error")
    
else:
    value = int(input())
    if value <= 0:
        print ("error")
        
    if value == 1 : 
        print(feet_to_cm(value))
        
    if value == 2:
        print(inches_to_cm(value))
    
    if value == 3:
        print(yards_to_cm(value))
        